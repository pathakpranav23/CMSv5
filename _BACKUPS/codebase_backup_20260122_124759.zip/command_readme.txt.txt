First, to activate venc run the following command on python terminal

	C:\project\CMSv5 [0:] $ & c:/project/CMSv5/venv/Scripts/Activate.ps1

Then, to run the app type the following command

	C:\project\CMSv5 [0:] $ python app.py